package Funds;

public enum Profession {
    WORKER,
    BUILDER,
    DOCTOR
}
